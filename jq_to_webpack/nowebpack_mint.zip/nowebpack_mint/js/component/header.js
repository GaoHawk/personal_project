/*
* @Author: Administrator
* @Date:   2017-02-09 14:53:33
* @Last Modified by:   Administrator
* @Last Modified time: 2017-02-09 15:50:48
*/
var Header = {
     template: `
     <mt-header title="">
       <div slot="left" >
         <mt-button icon="back" @click.native="back"></mt-button>
       </div>
       <mt-button slot="right" icon="more"></mt-button>
     </mt-header>
      `
}
