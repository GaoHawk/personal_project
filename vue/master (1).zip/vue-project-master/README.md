
# vue-project

仿talkingcoder app

对应的代码步骤（1）（2）（3）（4）（5）……等在简书：http://www.jianshu.com/users/1b30f6121ce8/latest_articles

全文汇总在segmentfault：https://segmentfault.com/a/1190000006852262#articleHeader0
