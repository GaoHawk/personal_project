<template>
	<nav class="bar bar-tab">
		<!-- <slot></slot> -->
	</nav>
</template>
<style>
	
</style>