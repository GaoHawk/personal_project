<template>
	
	  <div class="pull-to-refresh-layer">
	      <div class="preloader"></div>
	      <div class="pull-to-refresh-arrow"></div>
	  </div>

</template>
<script>
	export default {
		
	}
</script>