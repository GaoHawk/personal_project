<template>
	<div class="buttons-tab">
	   <slot></slot>
	</div>
</template>
<script>
	
</script>