<template>
  <div class="vux-dev-tip">
    <slot></slot>
  </div>
</template>

<style>
.vux-dev-tip {
  padding:5px 10px;
  background-color: #FFCC00;
  color:#000;
  margin-bottom:0.3em;
  font-size:12px;
}
</style>
