import Timeline from './timeline'
import TimelineItem from './timeline-item'

module.exports = {
  Timeline,
  TimelineItem
}
