/*
* @Author: Administrator
* @Date:   2017-01-05 14:07:45
* @Last Modified by:   Administrator
* @Last Modified time: 2017-01-05 16:35:50
*/
// function generateText(){
//    var element = document.createElement('h2');
//    element.innerHTML = "Hello h2 world";
//    return element;
// }

// module.exports = generateText;
export default function(){
    var element = document.createElement('h2');
    element.innerHTML = "Hello h2 world hahaha";
    return element;
}
