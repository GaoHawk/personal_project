/*
 *
 *                                  Apache License
 *                            Version 2.0, January 2004
 *                         http://www.apache.org/licenses/
 *
 *    TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION
 *
 *    1. Definitions.
 *
 *       "License" shall mean the terms and conditions for use, reproduction,
 *       and distribution as defined by Sections 1 through 9 of this document.
 *
 *       "Licensor" shall mean the copyright owner or entity authorized by
 *       the copyright owner that is granting the License.
 *
 *       "Legal Entity" shall mean the union of the acting entity and all
 *       other entities that control, are controlled by, or are under common
 *       control with that entity. For the purposes of this definition,
 *       "control" means (i) the power, direct or indirect, to cause the
 *       direction or management of such entity, whether by contract or
 *       otherwise, or (ii) ownership of fifty percent (50%) or more of the
 *       outstanding shares, or (iii) beneficial ownership of such entity.
 *
 *       "You" (or "Your") shall mean an individual or Legal Entity
 *       exercising permissions granted by this License.
 *
 *       "Source" form shall mean the preferred form for making modifications,
 *       including but not limited to software source code, documentation
 *       source, and configuration files.
 *
 *       "Object" form shall mean any form resulting from mechanical
 *       transformation or translation of a Source form, including but
 *       not limited to compiled object code, generated documentation,
 *       and conversions to other media types.
 *
 *       "Work" shall mean the work of authorship, whether in Source or
 *       Object form, made available under the License, as indicated by a
 *       copyright notice that is included in or attached to the work
 *       (an example is provided in the Appendix below).
 *
 *       "Derivative Works" shall mean any work, whether in Source or Object
 *       form, that is based on (or derived from) the Work and for which the
 *       editorial revisions, annotations, elaborations, or other modifications
 *       represent, as a whole, an original work of authorship. For the purposes
 *       of this License, Derivative Works shall not include works that remain
 *       separable from, or merely link (or bind by name) to the interfaces of,
 *       the Work and Derivative Works thereof.
 *
 *       "Contribution" shall mean any work of authorship, including
 *       the original version of the Work and any modifications or additions
 *       to that Work or Derivative Works thereof, that is intentionally
 *       submitted to Licensor for inclusion in the Work by the copyright owner
 *       or by an individual or Legal Entity authorized to submit on behalf of
 *       the copyright owner. For the purposes of this definition, "submitted"
 *       means any form of electronic, verbal, or written communication sent
 *       to the Licensor or its representatives, including but not limited to
 *       communication on electronic mailing lists, source code control systems,
 *       and issue tracking systems that are managed by, or on behalf of, the
 *       Licensor for the purpose of discussing and improving the Work, but
 *       excluding communication that is conspicuously marked or otherwise
 *       designated in writing by the copyright owner as "Not a Contribution."
 *
 *       "Contributor" shall mean Licensor and any individual or Legal Entity
 *       on behalf of whom a Contribution has been received by Licensor and
 *       subsequently incorporated within the Work.
 *
 *    2. Grant of Copyright License. Subject to the terms and conditions of
 *       this License, each Contributor hereby grants to You a perpetual,
 *       worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 *       copyright license to reproduce, prepare Derivative Works of,
 *       publicly display, publicly perform, sublicense, and distribute the
 *       Work and such Derivative Works in Source or Object form.
 *
 *    3. Grant of Patent License. Subject to the terms and conditions of
 *       this License, each Contributor hereby grants to You a perpetual,
 *       worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 *       (except as stated in this section) patent license to make, have made,
 *       use, offer to sell, sell, import, and otherwise transfer the Work,
 *       where such license applies only to those patent claims licensable
 *       by such Contributor that are necessarily infringed by their
 *       Contribution(s) alone or by combination of their Contribution(s)
 *       with the Work to which such Contribution(s) was submitted. If You
 *       institute patent litigation against any entity (including a
 *       cross-claim or counterclaim in a lawsuit) alleging that the Work
 *       or a Contribution incorporated within the Work constitutes direct
 *       or contributory patent infringement, then any patent licenses
 *       granted to You under this License for that Work shall terminate
 *       as of the date such litigation is filed.
 *
 *    4. Redistribution. You may reproduce and distribute copies of the
 *       Work or Derivative Works thereof in any medium, with or without
 *       modifications, and in Source or Object form, provided that You
 *       meet the following conditions:
 *
 *       (a) You must give any other recipients of the Work or
 *           Derivative Works a copy of this License; and
 *
 *       (b) You must cause any modified files to carry prominent notices
 *           stating that You changed the files; and
 *
 *       (c) You must retain, in the Source form of any Derivative Works
 *           that You distribute, all copyright, patent, trademark, and
 *           attribution notices from the Source form of the Work,
 *           excluding those notices that do not pertain to any part of
 *           the Derivative Works; and
 *
 *       (d) If the Work includes a "NOTICE" text file as part of its
 *           distribution, then any Derivative Works that You distribute must
 *           include a readable copy of the attribution notices contained
 *           within such NOTICE file, excluding those notices that do not
 *           pertain to any part of the Derivative Works, in at least one
 *           of the following places: within a NOTICE text file distributed
 *           as part of the Derivative Works; within the Source form or
 *           documentation, if provided along with the Derivative Works; or,
 *           within a display generated by the Derivative Works, if and
 *           wherever such third-party notices normally appear. The contents
 *           of the NOTICE file are for informational purposes only and
 *           do not modify the License. You may add Your own attribution
 *           notices within Derivative Works that You distribute, alongside
 *           or as an addendum to the NOTICE text from the Work, provided
 *           that such additional attribution notices cannot be construed
 *           as modifying the License.
 *
 *       You may add Your own copyright statement to Your modifications and
 *       may provide additional or different license terms and conditions
 *       for use, reproduction, or distribution of Your modifications, or
 *       for any such Derivative Works as a whole, provided Your use,
 *       reproduction, and distribution of the Work otherwise complies with
 *       the conditions stated in this License.
 *
 *    5. Submission of Contributions. Unless You explicitly state otherwise,
 *       any Contribution intentionally submitted for inclusion in the Work
 *       by You to the Licensor shall be under the terms and conditions of
 *       this License, without any additional terms or conditions.
 *       Notwithstanding the above, nothing herein shall supersede or modify
 *       the terms of any separate license agreement you may have executed
 *       with Licensor regarding such Contributions.
 *
 *    6. Trademarks. This License does not grant permission to use the trade
 *       names, trademarks, service marks, or product names of the Licensor,
 *       except as required for reasonable and customary use in describing the
 *       origin of the Work and reproducing the content of the NOTICE file.
 *
 *    7. Disclaimer of Warranty. Unless required by applicable law or
 *       agreed to in writing, Licensor provides the Work (and each
 *       Contributor provides its Contributions) on an "AS IS" BASIS,
 *       WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 *       implied, including, without limitation, any warranties or conditions
 *       of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
 *       PARTICULAR PURPOSE. You are solely responsible for determining the
 *       appropriateness of using or redistributing the Work and assume any
 *       risks associated with Your exercise of permissions under this License.
 *
 *    8. Limitation of Liability. In no event and under no legal theory,
 *       whether in tort (including negligence), contract, or otherwise,
 *       unless required by applicable law (such as deliberate and grossly
 *       negligent acts) or agreed to in writing, shall any Contributor be
 *       liable to You for damages, including any direct, indirect, special,
 *       incidental, or consequential damages of any character arising as a
 *       result of this License or out of the use or inability to use the
 *       Work (including but not limited to damages for loss of goodwill,
 *       work stoppage, computer failure or malfunction, or any and all
 *       other commercial damages or losses), even if such Contributor
 *       has been advised of the possibility of such damages.
 *
 *    9. Accepting Warranty or Additional Liability. While redistributing
 *       the Work or Derivative Works thereof, You may choose to offer,
 *       and charge a fee for, acceptance of support, warranty, indemnity,
 *       or other liability obligations and/or rights consistent with this
 *       License. However, in accepting such obligations, You may act only
 *       on Your own behalf and on Your sole responsibility, not on behalf
 *       of any other Contributor, and only if You agree to indemnify,
 *       defend, and hold each Contributor harmless for any liability
 *       incurred by, or claims asserted against, such Contributor by reason
 *       of your accepting any such warranty or additional liability.
 *
 *    END OF TERMS AND CONDITIONS
 *
 *    APPENDIX: How to apply the Apache License to your work.
 *
 *       To apply the Apache License to your work, attach the following
 *       boilerplate notice, with the fields enclosed by brackets "[]"
 *       replaced with your own identifying information. (Don't include
 *       the brackets!)  The text should be enclosed in the appropriate
 *       comment syntax for the file format. We also recommend that a
 *       file or class name and description of purpose be included on the
 *       same "printed page" as the copyright notice for easier
 *       identification within third-party archives.
 *
 *    Copyright 2016 Alibaba Group
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.alibaba.weex.benchmark;

import android.support.test.InstrumentationRegistry;
import android.support.test.espresso.contrib.RecyclerViewActions;
import android.support.test.filters.SdkSuppress;
import android.support.test.runner.AndroidJUnit4;
import android.support.test.uiautomator.By;
import android.support.test.uiautomator.Direction;
import android.support.test.uiautomator.UiDevice;
import android.support.test.uiautomator.UiObject2;
import android.support.test.uiautomator.Until;
import android.text.TextUtils;
import android.util.Log;

import com.alibaba.weex.BenchmarkActivity;
import com.taobao.weex.ui.view.listview.WXRecyclerView;
import com.taobao.weex.utils.WXLogUtils;

import org.hamcrest.Matchers;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.matcher.ViewMatchers.withClassName;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(AndroidJUnit4.class)
public class BenchmarkTest {

  private static final String TAG = "benchmark";
  private static final int TIMES = 20;
  private static final int FLING_SPEED = 10000;
  private static final int SCROLL_SPEED = 5000;
  private static final int FRAMES = 120;
  private static final long WAIT_TIMEOUT = 10000;
  private static final float FPS = 30;
  private static final float FIRST_SCREEN_RENDER_TIME = 600F;
  private static List<Long> firstScreenRenderTime = new LinkedList<>();
  private static List<Long> flingFrameSeconds = new LinkedList<>();
  private static List<Long> scrollFrameSeconds = new LinkedList<>();
  private static final String DUMP_START = "Flags,IntendedVsync,Vsync,OldestInputEvent,NewestInputEvent,"
                                           + "HandleInputStart,AnimationStart,PerformTraversalsStart,DrawStart,"
                                           + "SyncQueued,SyncStart,IssueDrawCommandsStart,SwapBuffers,FrameCompleted,\n";
  private static final String DUMP_END = "---PROFILEDATA---";
  private static final String DUMP_COMMAND = "dumpsys gfxinfo com.alibaba.weex framestats reset";

  @Rule
  public BenchmarkActivityTestRule mActivityRule = new BenchmarkActivityTestRule(
      BenchmarkActivity.class);
  @Rule
  public RepeatRule repeatRule = new RepeatRule();
  private UiDevice mUiDevice;

  @Before
  public void init() {
    mUiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
  }

  @Test
  public void testFirstScreenPerformance() {
    List<Long> localTotalTime = new ArrayList<>(TIMES);
    for (int i = 0; i < TIMES; i++) {
      long currentTime = calcTime();
      localTotalTime.add(currentTime);
      Log.d(TAG, "FIRST_SCREEN_RENDER_TIME (activity not kill) " + currentTime + "ms");
    }
    BoxPlot boxPlot = new BoxPlot(localTotalTime);
    Log.i(TAG, "Average firstScreenRenderTime (activity not kill) " + boxPlot.draw());
    assertThat(boxPlot.getAverage(), Matchers.lessThan(FIRST_SCREEN_RENDER_TIME));
  }

  @Repeat(TIMES)
  @Test
  public void testFirstFirstScreenPerformance() {
    long currentTime = calcTime();
    firstScreenRenderTime.add(currentTime);
    Log.d(TAG, "FIRST_SCREEN_RENDER_TIME (activity killed) " + currentTime + " ms");
  }

  @Repeat(TIMES)
  @Test
  @SdkSuppress(minSdkVersion = 23)
  public void testFlingFPS() {
    UiObject2 uiObject2 = loadPageForFPS();
    if (uiObject2 != null) {
      uiObject2.fling(Direction.DOWN, FLING_SPEED);
      uiObject2.fling(Direction.DOWN, FLING_SPEED);
      uiObject2.fling(Direction.DOWN, FLING_SPEED);
      uiObject2.fling(Direction.DOWN, FLING_SPEED);
      processGfxInfo(flingFrameSeconds);
    }
  }

  @Repeat(TIMES)
  @Test
  @SdkSuppress(minSdkVersion = 23)
  public void testScrollFPS() {
    UiObject2 uiObject2 = loadPageForFPS();
    if (uiObject2 != null) {
      uiObject2.scroll(Direction.DOWN, 6, SCROLL_SPEED);
      processGfxInfo(scrollFrameSeconds);
    }
  }

  @AfterClass
  public static void count() {
    BoxPlot boxPlot = new BoxPlot(firstScreenRenderTime);
    Log.i(TAG, "Average firstScreenRenderTime (activity killed) " + boxPlot.draw());
    assertThat(boxPlot.getAverage(), Matchers.lessThan(FIRST_SCREEN_RENDER_TIME));
    BoxPlot flingPlot = new BoxPlot(flingFrameSeconds);
    Log.i(TAG, "Average Fling FPS : " + flingPlot.draw());
    assertThat(1000 / flingPlot.getMedian(), Matchers.greaterThan(FPS));
    BoxPlot scrollPlot = new BoxPlot(scrollFrameSeconds);
    Log.i(TAG, "Average Scroll FPS : " + scrollPlot.draw());
    assertThat(1000 / scrollPlot.getMedian(), Matchers.greaterThan(FPS));
  }

  private UiObject2 loadPageForFPS() {
    BenchmarkActivity benchmarkActivity = mActivityRule.getActivity();
    benchmarkActivity.loadWeexPage();
    onView(withClassName(Matchers.is(WXRecyclerView.class.getName()))).perform(RecyclerViewActions.scrollToPosition(0));
    return mUiDevice.wait(Until.findObject(By.desc(BenchmarkActivity.ROOT)), WAIT_TIMEOUT);
  }

  private void processGfxInfo(List<Long> container) {
    try {
      String line;
      String[] columns;
      long timeStart, timeEnd, duration;
      String result = mUiDevice.executeShellCommand(DUMP_COMMAND);
      //histogramGfxInfo(result);
      result = result.substring(result.indexOf(DUMP_START), result.lastIndexOf(DUMP_END));
      result = result.substring(DUMP_START.length());
      BufferedReader bufferedReader = new BufferedReader(new StringReader(result));
      List<Long> list = createList(bufferedReader);
      //Collections.sort(list);
      //Log.d(TAG, list.toString());
      container.addAll(list);
      BoxPlot boxPlot = new BoxPlot(list);
      boxPlot.draw();
      Log.d(TAG, "FPS : " + boxPlot.getMedian() + " ms");
    } catch (IOException e) {
      WXLogUtils.e(TAG, WXLogUtils.getStackTrace(e));
    }
  }

  private List<Long> createList(BufferedReader bufferedReader) throws IOException {
    String line;
    String[] columns;
    long timeStart, timeEnd, duration;
    List<Long> list = new ArrayList<>(FRAMES);
    while (!TextUtils.isEmpty(line = bufferedReader.readLine())) {
      columns = line.split(",");
      if (Long.parseLong(columns[0]) == 0) {
        timeStart = Long.parseLong(columns[1]);
        timeEnd = Long.parseLong(columns[columns.length - 1]);
        duration = timeEnd - timeStart;
        if (duration > 0) {
          list.add(TimeUnit.MILLISECONDS.convert(duration, TimeUnit.NANOSECONDS));
        }
      }
    }
    return list;
  }

  private long calcTime() {
    BenchmarkActivity benchmarkActivity = mActivityRule.getActivity();
    benchmarkActivity.loadWeexPage();
    onView(withClassName(Matchers.is(WXRecyclerView.class.getName()))).perform
        (RecyclerViewActions.scrollToPosition(0));
    return benchmarkActivity.getWXInstance().getWXPerformance().screenRenderTime;
  }

/*  private void histogramGfxInfo(String result) {
    try {
      String start = "HISTOGRAM: ";
      result = result.substring(result.indexOf(start));
      result = result.substring(start.length());
      BufferedReader bufferedReader = new BufferedReader(new StringReader(result));
      result = bufferedReader.readLine();
      List<Long> list = transformToLong(result.split("\\s"));
      Log.d(TAG, list.toString());
    } catch (IOException e) {
      WXLogUtils.e(TAG, WXLogUtils.getStackTrace(e));
    }
  }

  private List<Long> transformToLong(String[] string) {
    List<Long> array = new LinkedList<>();
    int count;
    long value;
    for (String item : string) {
      value = Long.parseLong(item.substring(0, item.indexOf("ms")));
      if (value > 0) {
        count = parseInt(item.substring(item.indexOf('=') + 1));
        for (int i = 0; i < count; i++) {
          array.add(value);
        }
      }
    }
    return array;
  }*/
}
