define('@weex-component/037a188b382be8b4caa073b6cf436427', function(require, exports, module) {

    ;

    ;
    module.exports.style = {}

    ;
    module.exports.template = {
        "type": "div",
        "children": [{
            "type": "text",
            "style": {
                "fontSize": 100
            },
            "attr": {
                "value": "Hello World."
            }
        }]
    }

    ;
})

// require module
bootstrap('@weex-component/037a188b382be8b4caa073b6cf436427', {
    "transformerVersion": "0.3.1"
})